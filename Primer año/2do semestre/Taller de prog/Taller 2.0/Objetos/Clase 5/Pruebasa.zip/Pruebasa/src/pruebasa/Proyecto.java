/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pruebasa;

/**
 *
 * @author marti
 */
public class Proyecto {
    private String nombre;
    private int codigo;
    private String director;
    private Investigador []investigadores;
    private int df=50;
    private int dl;

    
    public Proyecto(String nombre,int codigo,String director){
        this.investigadores=new Investigador[df];
        this.nombre=nombre;
        this.codigo=codigo;
        this.director=director;
        this.dl=0;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    
    
    public void agregarInvestigador(Investigador unInvestigador){
        if(dl<df){
            this.investigadores[dl]=unInvestigador;
            dl++;
        }
    }
    public double dineroTotalOtorgado(){
        double aux=0;
        int i;
        for(i=0;i<dl;i++){
            aux+=this.investigadores[i].getTotalSubsidios();
        }
        return aux;
    }
    public void otorgarTodos(String nombre_completo){
        int i;
        for (i=0;i<dl;i++){
            if(this.investigadores[i].getNombre().equals(nombre_completo)){
                this.investigadores[i].otorgarSubsidios();
            }
        }
    }

    @Override
    public String toString() {
        String aux=" ";
        int i;
        for(i=0;i<dl;i++){
            aux+=this.investigadores[i].toString();
        } 
        
        return "Nombre: "+this.nombre+" Codigo: "+this.codigo+" Director: "+this.director+"\n"+aux;
    }
   
}
