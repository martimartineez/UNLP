/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pruebasa;

/**
 *
 * @author marti
 */
public class ejer1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Proyecto metalurgica=new Proyecto("Metalurgica",302,"DR. Martinez");
       Investigador pepe=new Investigador("pepe",2,"Pintor");
       Investigador maria=new Investigador("maria",1,"abogada");
       Investigador pedro=new Investigador("pedro",3,"constructor");
       metalurgica.agregarInvestigador(pepe);
       metalurgica.agregarInvestigador(pedro);
       metalurgica.agregarInvestigador(maria);
       
       Subsidio mejora=new Subsidio(10000,"Mejoras");
       Subsidio comida=new Subsidio(5000,"comida");
       
       maria.agregarSubsidio(comida);
       maria.agregarSubsidio(mejora);
       
       Subsidio o=new Subsidio(200,"guiso");
       Subsidio p=new Subsidio(500,"Agua");
       pedro.agregarSubsidio(o);
       pedro.agregarSubsidio(p);
       
       Subsidio a=new Subsidio(555,"Fideos");
       Subsidio b=new Subsidio(555,"Lenteja");
       pepe.agregarSubsidio(a);
       pepe.agregarSubsidio(b);
       
       metalurgica.otorgarTodos("pepe");
       
       System.out.println(metalurgica.toString());
    }
    
}
