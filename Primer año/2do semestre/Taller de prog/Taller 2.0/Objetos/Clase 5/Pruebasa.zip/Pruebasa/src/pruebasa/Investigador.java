/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pruebasa;

/**
 *
 * @author marti
 */
public class Investigador {
    private String nombre;
    private int categoria;
    private String especialidad;
    private Subsidio[]subsidios;
    private int df=5;
    private int dl;

    public Investigador(String nombre, int categoria, String especialidad) {
        this.nombre = nombre;
        this.categoria = categoria;
        this.especialidad = especialidad;
        this.subsidios=new Subsidio[df];
        this.dl=0;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCategoria() {
        return categoria;
    }

    public void setCategoria(int categoria) {
        this.categoria = categoria;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }
    
    public void agregarSubsidio(Subsidio unSubsidio){
        if(dl<df){
            this.subsidios[dl]=unSubsidio;
            dl++;
        }
    }
    
    public double getTotalSubsidios(){
        int i;
        double cant=0;
        for(i=0;i<dl;i++){
            if(this.subsidios[i].isOtorgado()==true){
                cant+=this.subsidios[i].getMonto();
            }
        }
        return cant;
        
    }
    
    public void otorgarSubsidios(){
        int i;
        for(i=0;i<dl;i++){
            this.subsidios[i].setOtorgado();
        }
    }
    public String toString(){
       return "nombre: "+this.nombre+" catergoria: "+this.categoria+" especialidad: "+this.especialidad+" total dinero de subsidios: "+this.getTotalSubsidios()+"\n"; 
    }
}
